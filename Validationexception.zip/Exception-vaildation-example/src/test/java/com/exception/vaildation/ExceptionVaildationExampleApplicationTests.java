package com.exception.vaildation;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExceptionVaildationExampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
