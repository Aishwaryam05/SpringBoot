package com.exception.vaildation.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.exception.vaildation.dto.UserRequest;
import com.exception.vaildation.entity.User;
import com.exception.vaildation.exception.UserNotFoundException;
import com.exception.vaildation.service.Userservice;

import jakarta.validation.Valid;


@RestController
public class UserController {

	@Autowired
	private Userservice service;
	
	//List
	@PostMapping("/signup")
	public ResponseEntity<User> saveUser(@RequestBody @Valid UserRequest userrequest){
		return new ResponseEntity<>(service.saveUser(userrequest),HttpStatus.CREATED);	
	}
	
	@GetMapping("/findAll")
	public ResponseEntity<List<User>> getAllUsersInfo(){
        return ResponseEntity.ok(service.getALlUsers());
	}
	
	 @GetMapping("find/{id}")
	    public ResponseEntity<User> getUser(@PathVariable int id) throws UserNotFoundException {
	        return ResponseEntity.ok(service.getUser(id));
	    }
}