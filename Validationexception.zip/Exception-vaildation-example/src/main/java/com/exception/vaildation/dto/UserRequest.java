package com.exception.vaildation.dto;


import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor(staticName = "build")
@NoArgsConstructor
public class UserRequest {
	@NotNull(message = "username should not be null")
	private String name;
	@Email(message = "Invaild email correct format is abc@gmail.com")
	private String email;
	@Pattern(regexp = "^\\d{10}$",message = "Mobile have 10 digit")
	private String mobile;
	@NotBlank(message = "Field should not blank")
	private String gender;
	@Min(18)
	@Max(40)
	private int age;
	@NotBlank(message = "Field should not be empty")
	private String nationality;
}
