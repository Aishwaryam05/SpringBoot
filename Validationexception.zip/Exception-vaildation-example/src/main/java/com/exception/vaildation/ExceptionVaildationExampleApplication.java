package com.exception.vaildation;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExceptionVaildationExampleApplication {

	public static void main(String[] args) {
		SpringApplication.run(ExceptionVaildationExampleApplication.class, args);
	}

}
