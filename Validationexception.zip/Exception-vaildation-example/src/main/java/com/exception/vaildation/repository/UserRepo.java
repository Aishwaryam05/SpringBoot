package com.exception.vaildation.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.exception.vaildation.entity.User;


public interface UserRepo extends JpaRepository<User, Integer>{

	User findById(int id);
}
