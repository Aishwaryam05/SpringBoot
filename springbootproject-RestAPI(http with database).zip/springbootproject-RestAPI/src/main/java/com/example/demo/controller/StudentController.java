package com.example.demo.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entity.Student;
import com.example.demo.services.StudentService;

@RestController
public class StudentController
{
 /*	
	@GetMapping("/student1")
	public Student getStudent()
	{
		// return "this is just the get request testing";
		Student s1 = new Student();
		s1.setSid(101);
		s1.setName("Kajal");
		s1.setCity("Pune");
		return s1;
	}
	*/
	@Autowired
	private StudentService studentservice;
	//get the list of all the students
	@GetMapping("/student1")
	public ResponseEntity<List<Student>> getStudent()
	{
		List<Student>list=studentservice.getAllStudents();
		if(list.size()<=0)
		{
			return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
		}

		return ResponseEntity.of(Optional.of(list));
	}
	
	//to get the data of id that is passed
	@GetMapping("student/{id}")
	public ResponseEntity<Student>getStudent(@PathVariable("id")int id)
	{
		Student student=studentservice.getStudentById(id);
		if(student==null)
		{
			return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
		}
		return ResponseEntity.of(Optional.of(student));
	}
	
	//to insert the data
	@PostMapping("/student1")
	public Student addStudent(@RequestBody Student student)
	{
		Student s=this.studentservice.addStudent(student);
		System.out.println("The student is inserted");
		return s;
	}
	
	
	  //to delete a particular data
	  
//	  @DeleteMapping("/student1/{id}") public void
//	  deleteStudent(@PathVariable("id")int id) 
//	  {
//	  this.studentservice.deleteStudentById(id); 
//	  }
	
	//to delete a particular data
		@DeleteMapping("/student1/{id}")
		public ResponseEntity<Void>deleteStudent(@PathVariable("id")int id)
		{
			try
			{
			this.studentservice.deleteStudentById(id);
			return ResponseEntity.status(HttpStatus.NO_CONTENT).build();
			}
			catch(Exception e)
			{
				e.printStackTrace();
				return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
				
			}
		}
	 
	
	//to update the data in the list
//	@PutMapping("student1/{id}")
//	public Student updateStudent(@RequestBody Student student,@PathVariable("id")int id)
//	{
//		this.studentservice.updateStudent(student,id);
//		return student;
//	}
		
		//to update the data in the list
		@PutMapping("student1/{id}")
		public ResponseEntity<Student> updateStudent(@RequestBody Student student,@PathVariable("id")int id)
		{
			try
			{
			this.studentservice.updateStudent(student,id);
			return ResponseEntity.ok().body(student);
			}
			catch(Exception e)
			{
				e.printStackTrace();
				return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
			}
		}

	

}
