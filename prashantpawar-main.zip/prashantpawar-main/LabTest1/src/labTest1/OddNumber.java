package labTest1;

public class OddNumber {

	public static void main(String[] args) {
		System.out.print("odd numbers from 1 to 20 are :");
		for (int i = 1; i <=20; i++) {
			if (i%2==1) {
				System.out.print(", "+i);
			}
		}

	}

}
