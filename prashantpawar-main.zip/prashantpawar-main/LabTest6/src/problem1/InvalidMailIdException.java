package problem1;

public class InvalidMailIdException extends Exception{

	public InvalidMailIdException() {
		super();
	}

	public InvalidMailIdException(String message) {
		super(message);	}
        
}
