export class Course {
    cid:number=0;
    cname:string='';
    cduration:string='';
    cfees:number=0.00;
}
