package com.example.CollegeMgt;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CollegeMgtApplicationTests {

	@Test
	void contextLoads() {
	}

}
