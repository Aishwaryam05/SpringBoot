package com.example.CollegeMgt;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CollegeMgtApplication {

	public static void main(String[] args) {
		SpringApplication.run(CollegeMgtApplication.class, args);
	}

}
