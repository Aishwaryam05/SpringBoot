package Problem2;

public interface Shape {
	void RectangleArea(double length,double breadth);
	void SquareArea(double side);
	void CircleArea(double radius);
}
