package Problem1;

public abstract class Bank {
	//abstract method
abstract int getBalance();
}
