package Problem1;

public class BankB extends Bank {

	@Override
	//returns available balance
	int getBalance() {
		return 1500;
	}

}
