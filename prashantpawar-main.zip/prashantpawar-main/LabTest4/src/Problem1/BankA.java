package Problem1;

public class BankA extends Bank {

	@Override
	//returns available balance
	int getBalance() {
		return 1000;
	}

}
