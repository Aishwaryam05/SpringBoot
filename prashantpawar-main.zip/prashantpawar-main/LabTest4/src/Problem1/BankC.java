package Problem1;

public class BankC extends Bank {

	@Override
	//returns available balance
	int getBalance() {
		return 2000;
	}

}
