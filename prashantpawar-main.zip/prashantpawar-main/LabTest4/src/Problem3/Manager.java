package Problem3;

public class Manager extends Member {
private String department;

public String getDepartment() {
	return department;
}

public void setDepartment(String department) {
	this.department = department;
}

}
